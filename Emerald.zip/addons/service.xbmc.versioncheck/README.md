XBMC Versioncheck
=========================

This service checks the installed XBMC version against the next available one and notifies you if there is a new version available.
When a new version comes out the versions.txt should be updated to reflect the latest version available.
When updating the version.txt always put latest release at the top since the list is read in chronilogical order.
